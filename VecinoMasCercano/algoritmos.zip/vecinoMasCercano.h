#ifndef VECINO_MAS_CERCANO
#define VECINO_MAS_CERCANO


#include <vector>

std::vector<int> vecinoMasCercano(const std::vector<std::vector<double>>&matriz, int incio, int N);

#endif