#ifndef PRINT_TOUR
#define PRINT_TOUR

#include <vector>


void PrintTour(std::vector<int> tour);



#endif


